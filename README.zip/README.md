Write an application integer-division that divides numbers and prints result into console. + JUnit tests(!!!).

Example of result:
22223|22
22   |---
  22 |101
  ---
    3